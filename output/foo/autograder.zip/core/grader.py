
from .managers import ModuleManager


def main():
    ModuleManager.grade()

if __name__ == "__main__":
    main()


